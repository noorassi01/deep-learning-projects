#!/bin/bash

rm -f data.npy vocab.pkl input.txt
ln -s $1 input.txt
